import Mathlib
import GroupApproximation.ThirdParty.FLT.Definitions.Def_GroupCohomology_TateCohomology
import GroupApproximation.ThirdParty.FLT.Definitions.Def_GroupCohomology_TateDimensionShift
import GroupApproximation.ThirdParty.FLT.P2M.Util
namespace P2MW.S_Rep_indBotPi_indBotSigma

set_option autoImplicit false
universe u
open CategoryTheory Rep

set_option maxHeartbeats 1600000
set_option synthInstance.maxHeartbeats 1600000

theorem solution {k G : Type u} [CommRing k] [Group G] (A : Rep.{u} k G) (a : A) :
    (Rep.indBotπ A).hom (A.indBotσ a) = a := by
  show (Rep.indBotπ A).hom (A.indBotMk 1 a) = a
  simp [Rep.indBotπ, Rep.indBotMk, Rep.indResHomEquiv]
